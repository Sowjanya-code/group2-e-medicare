import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Userlogin } from '../adminlogin';
import { AdminService } from '../Services/admin.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css'],
})
export class AdminloginComponent implements OnInit {
  message: string;

  adminLogin: Userlogin = new Userlogin();

  constructor(private adminService: AdminService, private router: Router) {}

  ngOnInit(): void {}



  // login() {
  //   // console.log(JSON.stringify(this.adminLogin));
  //   this.adminService.adminLogin(this.adminLogin).subscribe((adminStatus) => {
  //     alert(JSON.stringify(adminStatus));
  //     console.log(adminStatus);
  //     if (adminStatus != null) {
  //       this.message = '';
  //       sessionStorage.setItem('currentAdminId', adminStatus.id.toString());
  //       sessionStorage.setItem('currentAdminName', adminStatus.name);
  //       this.message = 'Login succesful';
  //       alert('Login succesful.');

  //       this.router.navigate(['/customerdashboard']);
  //     } else {
  //       this.message = 'Invalid Credentials';
  //     }
  //   });
  // }
  login() {
    console.log(this.adminLogin);
    if (this.adminLogin.id == 'Admin' && this.adminLogin.password == 'Admin') {
      this.router.navigate(['/adminhome']);
      alert('TAKING TO ADMIN HOME');
    } else alert('SORRY WRONG CREDENTIALS..');
  }
}
