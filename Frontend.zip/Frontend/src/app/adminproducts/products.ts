export class Product {
    pid: number = 0;
    pname: string = "";
    price: number = 0;
    pqty: number = 0;
    ptype: string = "";
    status: string = "";
    description: string = "";
    seller: string = "";
    productImg: string = "";
  
    constructor() {
      this.pqty = 0;
      this.ptype = "";
      this.status = "";
    }
  }
  