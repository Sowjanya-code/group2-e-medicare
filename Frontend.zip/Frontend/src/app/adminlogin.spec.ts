import { Adminlogin } from './adminlogin';

describe('Adminlogin', () => {
  it('should create an instance', () => {
    expect(new Adminlogin()).toBeTruthy();
  });
});
