import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {  Userlogin } from '../adminlogin';

import { Product } from '../adminproducts/products';
import {  User } from '../TS/admin';



@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }

  baseurl = "http://localhost:8686/product" 

  baseurl1 = "http://localhost:8686/login" 


  editProduct(id:number,product:Product){
    console.log(id);
    console.log(product)
    return this.http.put<any[]>(this.baseurl+'/editProduct/'+id,product)
  }


   //to make customer regsitration
   adminregister(user:User):Observable<any>{
    return this.http.post<User> ("http://localhost:8686/api/v1/register",user);

  }

  getAdmin(email: string, password: string): Observable<User> {
    const url = `http://localhost:8686/api/v1/getUser?email=${email}&password=${password}`;
    return this.http.get<User>(url);
    }

    adminLogin(userlogin:Userlogin):Observable<User>{
      return this.http.post<User>("http://localhost:8686/api/v1/loginAdmin",userlogin)
    }
  

  listAllProducts(){
    return this.http.get<any[]>(this.baseurl+'/productlist')
  }

  delete(id:number)
  {
    return this.http.delete<any[]>(this.baseurl+'/delProduct/'+id)
  }

  addProduct(product:Product){
    return this.http.post<any[]>(this.baseurl+'/addProduct',product)
  }

  update(id:number){
    return this.http.post<any[]>(this.baseurl+'/toggleProduct/'+id,Product);
  }

  updateSecond(id:number){
    return this.http.post<any[]>(this.baseurl+'/toggleProductSecond/'+id,Product);
  }

  listAllCustomers(){
    return this.http.get<any[]>(this.baseurl1+'/getUser')
  }



  UserLogin(userlogin:Userlogin):Observable<User>{
    return this.http.post<User>("http://localhost:8686/login/loginUser",userlogin)
  }

  

  
getUser(email: string, password: string): Observable<User> {
  const url = `http://localhost:8686/login/getUser?email=${email}&password=${password}`;
  return this.http.get<User>(url);
  }
}