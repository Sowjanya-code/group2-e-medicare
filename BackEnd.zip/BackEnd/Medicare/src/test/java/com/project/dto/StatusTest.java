package com.project.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class StatusTest {

    private Status status;

    @BeforeEach
    public void setUp() {
        status = new Status();
        status.setStatus(Status.StatusType.SUCCESS);
        status.setMessage("Operation successful");
    }

    @Test
    public void testGetStatus() {
        assertEquals(Status.StatusType.SUCCESS, status.getStatus());
    }

    @Test
    public void testSetStatus() {
        status.setStatus(Status.StatusType.FAILURE);
        assertEquals(Status.StatusType.FAILURE, status.getStatus());
    }

    @Test
    public void testGetMessage() {
        assertEquals("Operation successful", status.getMessage());
    }

    @Test
    public void testSetMessage() {
        status.setMessage("Operation failed");
        assertEquals("Operation failed", status.getMessage());
    }
}
