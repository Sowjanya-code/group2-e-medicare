package com.project.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LoginDtoUserTest {

    private LoginDtoUser loginDtoUser;

    @BeforeEach
    public void setUp() {
        loginDtoUser = new LoginDtoUser();
        loginDtoUser.setId(1);
        loginDtoUser.setEmail("john.doe@example.com");
        loginDtoUser.setName("John Doe");
        loginDtoUser.setPassword("password123");
    }

    @Test
    public void testGetId() {
        assertEquals(1, loginDtoUser.getId());
    }

    @Test
    public void testSetId() {
        loginDtoUser.setId(2);
        assertEquals(2, loginDtoUser.getId());
    }

    @Test
    public void testGetEmail() {
        assertEquals("john.doe@example.com", loginDtoUser.getEmail());
    }

    @Test
    public void testSetEmail() {
        loginDtoUser.setEmail("jane.doe@example.com");
        assertEquals("jane.doe@example.com", loginDtoUser.getEmail());
    }

    @Test
    public void testGetName() {
        assertEquals("John Doe", loginDtoUser.getName());
    }

    @Test
    public void testSetName() {
        loginDtoUser.setName("Jane Doe");
        assertEquals("Jane Doe", loginDtoUser.getName());
    }

    @Test
    public void testGetPassword() {
        assertEquals("password123", loginDtoUser.getPassword());
    }

    @Test
    public void testSetPassword() {
        loginDtoUser.setPassword("newpassword");
        assertEquals("newpassword", loginDtoUser.getPassword());
    }
}
