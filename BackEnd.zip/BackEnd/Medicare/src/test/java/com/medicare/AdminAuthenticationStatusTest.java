package com.medicare;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.medicare.admin.AdminAuthenticationStatus;

public class AdminAuthenticationStatusTest {

    private AdminAuthenticationStatus authStatus;

    @BeforeEach
    public void setUp() {
        authStatus = new AdminAuthenticationStatus("admin", "password123", true);
    }

    @Test
    public void testGetAdmin() {
        assertEquals("admin", authStatus.getAdmin());
    }

    @Test
    public void testSetAdmin() {
        authStatus.setAdmin("newAdmin");
        assertEquals("newAdmin", authStatus.getAdmin());
    }

    @Test
    public void testGetPassword() {
        assertEquals("password123", authStatus.getPassword());
    }

    @Test
    public void testSetPassword() {
        authStatus.setPassword("newPassword");
        assertEquals("newPassword", authStatus.getPassword());
    }

    @Test
    public void testIsAdminAuthenticated() {
        assertTrue(authStatus.isAdminAuthenticated());
    }

    @Test
    public void testSetAdminAuthenticated() {
        authStatus.setAdminAuthenticated(false);
        assertFalse(authStatus.isAdminAuthenticated());
    }

    @Test
    public void testAdminAuthenticationStatusConstructor() {
        AdminAuthenticationStatus newAuthStatus = new AdminAuthenticationStatus("admin2", "pass456", false);
        assertEquals("admin2", newAuthStatus.getAdmin());
        assertEquals("pass456", newAuthStatus.getPassword());
        assertFalse(newAuthStatus.isAdminAuthenticated());
    }
}
