package com.medicare;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.medicare.admin.AdminDto;

public class AdminDtoTest {

    private AdminDto adminDto;

    @BeforeEach
    public void setUp() {
        adminDto = new AdminDto();
        adminDto.setName("admin");
        adminDto.setPassword("password123");
    }

    @Test
    public void testGetName() {
        assertEquals("admin", adminDto.getName());
    }

    @Test
    public void testSetName() {
        adminDto.setName("newAdmin");
        assertEquals("newAdmin", adminDto.getName());
    }

    @Test
    public void testGetPassword() {
        assertEquals("password123", adminDto.getPassword());
    }

    @Test
    public void testSetPassword() {
        adminDto.setPassword("newPassword");
        assertEquals("newPassword", adminDto.getPassword());
    }
}
