package com.medicare;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.medicare.admin.Admin;

public class AdminTest {

    private Admin admin;

    @BeforeEach
    public void setUp() {
        admin = new Admin(1, "John Doe", "password123");
    }

    @Test
    public void testGetAdminId() {
        assertEquals(1, admin.getAdminId());
    }

    @Test
    public void testSetAdminId() {
        admin.setAdminId(2);
        assertEquals(2, admin.getAdminId());
    }

    @Test
    public void testGetName() {
        assertEquals("John Doe", admin.getName());
    }

    @Test
    public void testSetName() {
        admin.setName("Jane Doe");
        assertEquals("Jane Doe", admin.getName());
    }

    @Test
    public void testGetPassword() {
        assertEquals("password123", admin.getPassword());
    }

    @Test
    public void testSetPassword() {
        admin.setPassword("newpassword");
        assertEquals("newpassword", admin.getPassword());
    }

    @Test
    public void testAdminConstructor() {
        Admin newAdmin = new Admin(3, "Alice", "alicepassword");
        assertNotNull(newAdmin);
        assertEquals(3, newAdmin.getAdminId());
        assertEquals("Alice", newAdmin.getName());
        assertEquals("alicepassword", newAdmin.getPassword());
    }

    @Test
    public void testDefaultConstructor() {
        Admin defaultAdmin = new Admin();
        assertNotNull(defaultAdmin);
    }
}
