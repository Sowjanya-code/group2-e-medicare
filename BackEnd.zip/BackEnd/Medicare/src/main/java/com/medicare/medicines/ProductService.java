package com.medicare.medicines;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    ProductRepository productRepository;

    public void addProduct(Product product) {
        productRepository.save(product);
    }

    public List<Product> editProduct(int pid, Product product) {
        Product existingProduct = productRepository.findById(pid).orElseThrow(() -> new RuntimeException("Product not found"));
        existingProduct.setPname(product.getPname());
        existingProduct.setPrice(product.getPrice());
        existingProduct.setStatus(product.getStatus());
        productRepository.save(existingProduct);
        return productRepository.findAll();
    }

    public List<Product> delProduct(int pid) {
        productRepository.deleteById(pid);
        return productRepository.findAll();
    }

    public List<Product> listAllPrd() {
        return productRepository.findAll();
    }

    public List<Product> toggleProduct(int pid) {
        Product product = productRepository.findById(pid).orElseThrow(() -> new RuntimeException("Product not found"));
        product.setStatus("A");
        productRepository.save(product);
        return productRepository.findAll();
    }

    public List<Product> toggleProductSecond(int pid) {
        Product product = productRepository.findById(pid).orElseThrow(() -> new RuntimeException("Product not found"));
        product.setStatus("N");
        productRepository.save(product);
        return productRepository.findAll();
    }

    public List<Product> Antibiotic() {
        return productRepository.findByCategory("Antibiotic");
    }

    public List<Product> Analgesics() {
        return productRepository.findByCategory("Analgesics");
    }

    public List<Product> Antipyretics() {
        return productRepository.findByCategory("Antipyretics");
    }
}
