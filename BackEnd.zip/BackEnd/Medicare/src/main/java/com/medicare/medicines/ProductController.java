package com.medicare.medicines;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    ProductService pservice;

    @PostMapping("/addProduct")
    public ResponseEntity<Integer> addProduct(@RequestBody Product product) {
        pservice.addProduct(product);
        return ResponseEntity.ok(product.getPid());
    }

    @PutMapping("/editProduct/{pid}")
    public ResponseEntity<List<Product>> editProduct(@PathVariable("pid") int pid, @RequestBody Product product) {
        return ResponseEntity.ok(pservice.editProduct(pid, product));
    }

    @DeleteMapping("/delProduct/{pid}")
    public ResponseEntity<List<Product>> delProduct(@PathVariable("pid") int pid) {
        return ResponseEntity.ok(pservice.delProduct(pid));
    }

    @GetMapping("/productlist")
    public ResponseEntity<List<Product>> listAllPrd() {
        return ResponseEntity.ok(pservice.listAllPrd());
    }

    @PostMapping("/toggleProduct/{pid}")
    public ResponseEntity<List<Product>> toggleProduct(@PathVariable("pid") int pid) {
        return ResponseEntity.ok(pservice.toggleProduct(pid));
    }

    @PostMapping("/toggleProductSecond/{pid}")
    public ResponseEntity<List<Product>> toggleProductSecond(@PathVariable("pid") int pid) {
        return ResponseEntity.ok(pservice.toggleProductSecond(pid));
    }

    @GetMapping("/Antibiotic")
    public ResponseEntity<List<Product>> Antibiotic() {
        return ResponseEntity.ok(pservice.Antibiotic());
    }

    @GetMapping("/Analgesics")
    public ResponseEntity<List<Product>> Analgesics() {
        return ResponseEntity.ok(pservice.Analgesics());
    }

    @GetMapping("/Antipyretics")
    public ResponseEntity<List<Product>> Antipyretics() {
        return ResponseEntity.ok(pservice.Antipyretics());
    }
}
