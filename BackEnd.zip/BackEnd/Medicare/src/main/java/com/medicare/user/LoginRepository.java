package com.medicare.user;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface LoginRepository extends JpaRepository<Login, Integer> {

    @Query("SELECT l FROM Login l WHERE l.email = :email AND l.password = :password")
    Login findByEmailAndPassword(@Param("email") String email, @Param("password") String password);

//    @Query("SELECT l FROM Login l WHERE l.id = :id")
//    Login findById(@Param("id") int id);

    @Query("SELECT l FROM Login l")
    List<Login> findAll();
}
