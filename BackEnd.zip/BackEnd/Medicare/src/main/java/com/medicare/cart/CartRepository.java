package com.medicare.cart;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CartRepository extends JpaRepository<Cart, Integer> {

    @Query("SELECT c FROM Cart c WHERE c.lid = :lid")
    List<Cart> findByLoginId(@Param("lid") int lid);

    @Query("SELECT SUM(c.price) FROM Cart c WHERE c.lid = :lid")
    List<Object> sumOfProducts(@Param("lid") int lid);

    @Query("SELECT c FROM Cart c WHERE c.lid = :lid AND c.booked = 'Booked'")
    List<Cart> findBookedProducts(@Param("lid") int lid);

    @Query("SELECT c FROM Cart c WHERE c.pname LIKE %:pname%")
    List<Cart> findByNameContaining(@Param("pname") String pname);

}
