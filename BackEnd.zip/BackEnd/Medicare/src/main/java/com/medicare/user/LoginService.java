package com.medicare.user;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class LoginService {

    @Autowired
    LoginRepository loginRepository;

    public void register(Login login) {
        loginRepository.save(login);
    }

    public Login loginUser(String email, String password) {
        return loginRepository.findByEmailAndPassword(email, password);
    }

    public List<Login> getUser() {
        return loginRepository.findAll();
    }

    public Login getUserProfile(int id) {
         Optional<Login> l=loginRepository.findById(id);
         Login login=l.get();
         return login;
    }

    public void updateProfile(int id, Login login) {
       Optional<Login>  l=  loginRepository.findById(id);
       if(l.isPresent()) {
    	   Login existingLogin=l.get();
        existingLogin.setName(login.getName());
        existingLogin.setPassword(login.getPassword());
        loginRepository.save(existingLogin);
       }
    }
}
