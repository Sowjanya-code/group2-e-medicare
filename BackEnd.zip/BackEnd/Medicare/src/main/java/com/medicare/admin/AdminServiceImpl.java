package com.medicare.admin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl {
	@Autowired
	private AdminRepository adminRepository;

	public void register(Admin admin) {
		adminRepository.save(admin);
	}

	public Admin loginAdmin(String name, String password) {
		return adminRepository.findByNameAndPassword(name, password);
	}

//	public AdminAuthenticationStatus getAdminStatus(String email, String password) {
//		AdminAuthenticationStatus authStatus;
//		Admin admin1=adminRepository.findByEmailAndPassword(email, password);
//		if(admin1!=null) {
////			authStatus=new AdminAuthenticationStatus(admin1.getAdmin(),admin1.getPassword(),true);
//		}else {
//			authStatus=new AdminAuthenticationStatus(null,null,false);
//		}
//		return null;
//	}

}
