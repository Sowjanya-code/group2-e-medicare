package com.medicare.cart;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CartService {

    @Autowired
    CartRepository cartRepository;

    public List<Cart> listAllPrdinCart() {
        return cartRepository.findAll();
    }

    public List<Cart> cartlistbyloginsid(int id) {
        return cartRepository.findByLoginId(id);
    }

    public int addToCart(Cart cart) {
        Cart savedCart = cartRepository.save(cart);
        return savedCart.getId();
    }

    public List<Object> sumofproduct(int id) {
        return cartRepository.sumOfProducts(id);
    }

    public List<Cart> bookedProducts(int id) {
        return cartRepository.findBookedProducts(id);
    }

    public List<Cart> makebooking(int id) {
        List<Cart> carts = cartRepository.findByLoginId(id);
        for (Cart cart : carts) {
            cart.setBooked("Booked");
            cartRepository.save(cart);
        }
        return carts;
    }

    public List<Cart> delProductfromCart(int pid) {
        cartRepository.deleteById(pid);
        return cartRepository.findAll();
    }

    public List<Cart> search(String name) {
        return cartRepository.findByNameContaining(name);
    }
}
