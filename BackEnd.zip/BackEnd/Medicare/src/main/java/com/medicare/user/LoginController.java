package com.medicare.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.dto.LoginDtoUser;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    LoginService loginService;

    @PostMapping("/register")
    public ResponseEntity<Integer> addLogin(@RequestBody Login login) {
        loginService.register(login);
        return ResponseEntity.ok(login.getId());
    }
    
    @PostMapping("/loginUser")
    public ResponseEntity<Login> userLogin(@RequestBody LoginDtoUser logindtouser) {
        Login login = loginService.loginUser(logindtouser.getEmail(), logindtouser.getPassword());
        return ResponseEntity.ok(login);
    }

    @GetMapping("/getUser")
    public ResponseEntity<List<Login>> getUser() {
        List<Login> users = loginService.getUser();
        return ResponseEntity.ok(users);
    }

    
    
    @GetMapping("/getUserProfile/{id}")
    public ResponseEntity<Login> getUserProfile(@PathVariable("id") int id) {
        Login userProfile = loginService.getUserProfile(id);
        return ResponseEntity.ok(userProfile);
    }

    @PutMapping("/UpdateProfile/{Id}")
    public ResponseEntity<Void> updateProfile(@PathVariable("Id") int Id, @RequestBody Login login) {
        loginService.updateProfile(Id, login);
        return ResponseEntity.ok().build();
    }
}
